# Forecast-app

> Programming Development Exercise
  For Web Developers Applying to Architech

## How to run

1) **Inside root directory run command**

``` bash
# serve static site. Port 9000
npm run server
```

2) **Open browser on page `http://localhost:9000/`**

## Modules 

> The project was made using:
- [Vue.js](https://vuejs.org/)
- [Vuex](https://vuex.vuejs.org/en/)
- [Chartkick](https://www.chartkick.com/vue) 
- Google API (Google Maps JavaScript API, Google Geocoding API, Google Places API)
- [Vue-google-autocomplete](https://github.com/olefirenko/vue-google-autocomplete)

## Structure

- `/src/components` folder with Vue components
- `/src/store` folder with Vuex structure
- `/src/config/endpoints` Openweathermap API endpoint with hardcoded API key

## Development

``` bash
# serve with hot reload at localhost:8080
npm run dev

# build for production with minification
npm run build

# build for production and view the bundle analyzer report
npm run build --report
```

