<template>
  <div id="app">
    <img class="weather-icon" src="/static/icon.png">
    <WeatherApp/>
  </div>
</template>

<script>
import WeatherApp from './components/WeatherApp'

export default {
  name: 'App',
  components: {
    WeatherApp
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  margin-top: 40px;
}
.weather-icon {
  width: 100px;
  margin-bottom: 20px;
}
</style>
