export default {
  get: {
    weatherAPI: (lat, lon) => `http://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&lang=en&type=like&units=metric&APPID=3b6f49e4217f5cf260383107a1f4169a`
  }
}
